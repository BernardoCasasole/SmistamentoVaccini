/* eslint-disable no-undef */
sap.ui.define([
],
    function (UriParameters) {
        return sap.ui.controller("vaccination.center.vaccinationcenters.ext.controller.ObjectPageExt", {

onPress: function(){
    var msg = "premuto!";
    sap.m.MessageBox(msg);
}
        })
    });