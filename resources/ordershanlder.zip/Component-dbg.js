sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("pharmorders.orders.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
