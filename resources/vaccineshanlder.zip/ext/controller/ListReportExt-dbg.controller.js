/* eslint-disable no-undef */
sap.ui.define([
],
    function (UriParameters) {
        return sap.ui.controller("vaccination.center.vaccinationcenters.ext.controller.ListReportExt", {


        })
    });